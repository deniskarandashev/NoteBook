package com.example.NoteBook.domain;

/**
 * @author Denis Karandashev
 * @project NoteBook
 * @date 22.05.2020
 */
public enum Role {
    USER;
}
